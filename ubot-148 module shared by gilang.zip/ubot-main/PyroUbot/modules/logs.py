__MODULE__ = "ʟᴏɢ"
__HELP__ = """
<blockquote>Bantuan Untuk Logs

perintah : <code>{0}logs</code> query > on or off
    mengaktifkan atau menonaktifkan logs</blockquote>
"""
