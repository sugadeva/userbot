import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "60"))

DEVS = list(map(int, os.getenv("DEVS", "6361013452").split()))

API_ID = int(os.getenv("API_ID", "27254318"))

API_HASH = os.getenv("API_HASH", "515c0f8f99279834c3283d7c440a0051")

BOT_TOKEN = os.getenv("BOT_TOKEN", "Bot Token Lu")

OWNER_ID = int(os.getenv("OWNER_ID", "Owner Id Lu"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002125842026 -1002053287763 -1002044997044 -1002022625433 -1002050846285 -1002400165299 -1002416419679 -1001473548283").split()))

RMBG_API = os.getenv("RMBG_API", "a6q")

MONGO_URL = os.getenv("MONGO_URL", "mongodb lu")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "id Gb / ch lu."))
